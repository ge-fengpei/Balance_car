#ifndef _SYSTEMCLOCK_H
#define _SYSTEMCLOCK_H

#include "stm32f10x.h"



void RCC_HSE_Config(u32 div,u32 pllm);
#endif
